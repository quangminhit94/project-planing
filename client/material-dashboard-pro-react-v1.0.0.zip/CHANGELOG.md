# Change Log

## [1.0.0] 2018-03-27
### Original Release
- Added Material-UI as base framework
- Added design from Material Dashboard Pro BS3 by Creative Tim
